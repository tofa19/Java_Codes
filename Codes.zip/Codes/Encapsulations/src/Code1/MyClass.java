package Code1;

public class MyClass {

	public static void main(String[] args) {
		Person p1 = new Person();
		
	p1.setName("Toufique Ahamed");
	p1.setAge(22);
    
	System.out.println("Name : "+p1.getName());
	System.out.println("Name : "+p1.getAge());

	}

}
