package Code2;

public class MyClass {

	public static void main(String[] args) {
		 Student s1 = new Student();
		 s1.setName("Toufique");
		 s1.setID(4980);
		 s1.setCgpa(3.84);
		 
		 System.out.println("Name : "+s1.getName());
		 System.out.println("ID : "+s1.getID());
		 System.out.println("CGPA : "+s1.getCgpa());

	}

}
