/**
 * 
 */
/**
 * @author Toufique
 *
 */
module Abstruction {
}