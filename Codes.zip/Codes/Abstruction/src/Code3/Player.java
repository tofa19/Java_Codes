package Code3;

public interface Player {
	public void play();
	public void stop();
	public void pause();
	public void reverse();
	

}
