package Code1;

public class Bird extends Animal{

	@Override
	public void eat() {
		
			System.out.println("Bird Can eat");
		
	}

	@Override
	public void move() {
		 System.out.println("Bird Can move");
		
	}
	public void fly() {
		
		System.out.println("Bird Can fly");
		
	}
	

}
