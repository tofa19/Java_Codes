package Code1;

public abstract class Animal {
	
	public abstract void eat();
	public abstract void move();
	public void life()
	{
		System.out.println("Animals Have life");
	}
}
