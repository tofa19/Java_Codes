package Code1;

public class Lion extends Animal {

	@Override
	public void eat() {
			System.out.println("Lion can eat");
			
		}

	@Override
	public void move() {
		
			System.out.println("Lion Can move");
			
		}
	public void Hunt() {
		
		System.out.println("Lion Can hunt");
		
	}

}
