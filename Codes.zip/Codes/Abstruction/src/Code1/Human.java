package Code1;

public class Human extends Animal {

	@Override
	public void eat() {
		System.out.println("Human Can eat");
		
	}

	@Override
	public void move() {
		System.out.println("Human Can move");
		
	}
	 public void talk() {
		System.out.println("Human Can talk");
		
	}

	
	

	
	
}
