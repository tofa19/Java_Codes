package Code2;

public class Line implements Drawing {

	public void draw() {
		System.out.println("I am Drawing a line");
		
	}


}
