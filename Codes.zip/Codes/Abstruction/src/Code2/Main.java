package Code2;

public class Main {

	public static void main(String[] args) {
		Line l1 = new Line();
		l1.draw();
		
		Circle c = new Circle();
		c.draw();

	}

}
