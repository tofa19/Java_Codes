package Code2;

public class Circle implements Drawing {

	

	@Override
	public void draw() {
		System.out.println("I am Drawing a Circle");
		
	}
	

}
