/**
 * 
 */
package Code2;

/**
 * @author Toufique
 *
 */
public interface Drawing {
	public void draw();

}
