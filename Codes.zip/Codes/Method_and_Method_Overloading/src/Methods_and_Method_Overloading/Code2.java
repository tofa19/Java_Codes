package Methods_and_Method_Overloading;

public class Code2 {

		public void sum(int num1,int num2)
		{
		System.out.println("The sum is "+(num1+num2))	;
		}
		
		public static void main(String[] args) {
			Code2 c =new Code2();
			int a =10;
			int b= 20;
			 c.sum(a,b);
			

		}

	}

