
package Methods_and_Method_Overloading;

/**adding two numbers using methods.
 * @author Toufique
 *
 */
public class Code1 {

	public static void sum(int num1,int num2)
	{
	System.out.println("The sum is "+(num1+num2))	;
	}
	public static void main(String[] args) {
		
		int a =10;
		int b= 20;
		 sum(a,b);
		

	}

}
