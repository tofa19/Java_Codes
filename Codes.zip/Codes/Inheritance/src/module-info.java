/**
 * 
 */
/**
 * @author Toufique
 *
 */
module Inheritance {
}