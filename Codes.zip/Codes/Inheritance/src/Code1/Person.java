package Code1;
/*
 * Example-3(COnverting UML to Java Code)
 */

public class Person {
	protected String name= " Toufique";
	protected int age= 22;

}
