package Code2;

public class Calculation {
	int z;
	
	public void addition(int a,int b)
	{
		z=a+b;
		System.out.println("Addition is "+z);
	}
	public void subtraction(int a,int b)
	{
		z=a-b;
		System.out.println("subtraction is "+z);
	}

}
