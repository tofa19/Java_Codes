
package Code3;


public class Boy extends Human{

	public void eat() {
		System.out.println("Boy eats");
	}
	public static void main(String[] args) {
		Boy b1 = new Boy();
		b1.eat();
	
	}}


