package Code3;

public class Human {
	public void eat() {
		System.out.println("Human can Eat");
	}

}
