package Code3;

public class Girl extends Human {
	
	public void eat() {
		System.out.println("Girl eats");
	}

	public static void main(String[] args) {
		Girl g1 = new Girl();
		g1.eat();

	}

}
